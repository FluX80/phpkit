<?php
die('Dieses Verzeichnis darf nicht dauerhaft auf dem Server verbleiben.<br/>
Die Scriptdateien in diesem Verzeichnis beinhalten Funktionen, die die Webseite sch&auml;digen k&ouml;nnen.<br/><br/>
This directory shouldn`t be permanently on the server.
The scriptfiles provides functions which can harm your website.');
?>