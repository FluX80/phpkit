function pkFreeFrames()
	{
	if(top != self)
		top.location = self.location;
	}