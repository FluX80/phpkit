<?php
header('Location: ./../');
exit;
?>