<?php
# PHPKIT WCMS | Web Content Management System
#
#
# YOU ARE NOT AUTHORISED TO CREATE ILLEGAL COPIES OF THIS
# FILE AND/OR TO REMOVE THIS INFORMATION
#
# SIE SIND NICHT BERECHTIGT, UNRECHTM�SSIGE KOPIEN DIESER
# DATEI ZU ERSTELLEN UND/ODER DIESE INFORMATIONEN ZU ENTFERNEN
#
# This file / the PHPKIT software is no freeware! For further 
# information please visit our website or contact us via email:
#
# Diese Datei / die PHPKIT Software ist keine Freeware! F�r weitere
# Informationen besuchen Sie bitte unsere Website oder kontaktieren uns per E-Mail:
#
# email     : info@phpkit.com
# website   : http://www.phpkit.com
# licence   : http://www.phpkit.com/licence
# copyright : Copyright (c) 2002-2009 mxbyte gbr | http://www.mxbyte.com


return array(
	0=>array(
		'code'=>' :-|',
		'path'=>'images/smilies/angry.gif'
		),		
	1=>array(
		'code'=>' :D',
		'path'=>'images/smilies/biggrin.gif'
		),
	2=>array(
		'code'=>' :o',
		'path'=>'images/smilies/confused.gif'
		),
	3=>array(
		'code'=>' 8-)',
		'path'=>'images/smilies/cool.gif'
		),
	4=>array(
		'code'=>' ;(',
		'path'=>'images/smilies/cry.gif'
		),
	5=>array(
		'code'=>' ;D',
		'path'=>'images/smilies/evil.gif'
		),
	6=>array(
		'code'=>' :(',
		'path'=>'images/smilies/frown.gif'
		),
	7=>array(
		'code'=>' :-)',
		'path'=>'images/smilies/laugh.gif'
		),
	8=>array(
		'code'=>' 8-|',
		'path'=>'images/smilies/rolleyes.gif'
		),
	9=>array(
		'code'=>' :-o',
		'path'=>'images/smilies/surprised.gif'
		),
	10=>array(
		'code'=>' :)',
		'path'=>'images/smilies/smilie.gif'
		),
	11=>array(
		'code'=>' ;)',
		'path'=>'images/smilies/wink.gif'
		),
	12=>array(
		'code'=>' :p',
		'path'=>'images/smilies/tongue.gif'
		),
	13=>array(
		'code'=>' (**)',
		'path'=>'images/smilies/hearts.gif'
		)
	);
?>