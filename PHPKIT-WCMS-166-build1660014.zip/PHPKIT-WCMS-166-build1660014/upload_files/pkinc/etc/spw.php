<?php
$this->setuppassword = md5('');

#Tragen Sie ihr individuelles Passwort zwischen den '' ein
#z.B. $this->setuppassword=md5('meinpasswort');
#enter your individual password between the ''
#f.e. $this->setuppassword=md5('myprivatepassword');
?>