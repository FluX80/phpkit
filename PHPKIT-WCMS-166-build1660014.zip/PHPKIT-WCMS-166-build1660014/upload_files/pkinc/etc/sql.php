<?php
define('pkPHPKIT_INSTALLED', false);
?>