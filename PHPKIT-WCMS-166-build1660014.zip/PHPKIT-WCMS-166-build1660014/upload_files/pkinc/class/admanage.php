<?php
# PHPKIT WCMS | Web Content Management System
#
#
# YOU ARE NOT AUTHORISED TO CREATE ILLEGAL COPIES OF THIS
# FILE AND/OR TO REMOVE THIS INFORMATION
#
# SIE SIND NICHT BERECHTIGT, UNRECHTMÄSSIGE KOPIEN DIESER
# DATEI ZU ERSTELLEN UND/ODER DIESE INFORMATIONEN ZU ENTFERNEN
#
# This file / the PHPKIT software is no freeware! For further 
# information please visit our website or contact us via email:
#
# Diese Datei / die PHPKIT Software ist keine Freeware! Für weitere
# Informationen besuchen Sie bitte unsere Website oder kontaktieren uns per E-Mail:
#
# email     : info@phpkit.com
# website   : http://www.phpkit.com
# licence   : http://www.phpkit.com/licence
# copyright : Copyright (c) 2002-2012 mxbyte gbr | http://www.mxbyte.com


if(!defined('pkFRONTEND'))
	return;
	

class pkAdmanage
	{
	var $SQL;			# object
	var $hash=array();	// 
	
	
	function __construct()
		{
		global $SQL;
		$this->SQL=&$SQL;
		}

	function get()
		{																																																													if(!@pkl ( 1))return NULL;																																																							
		$adview_maxcount=0;
		
		$result=$this->SQL->query("SELECT 
			* 
			FROM ".pkSQLTAB_ADVIEW." 
			WHERE adview_status='1'");
		while($adviewinfo=$this->SQL->fetch_assoc($result)) 
			{
			$this->hash[]=$adviewinfo; 
			$adview_maxcount += $adviewinfo['adview_relation'];
			}

		if(!$adview_maxcount>=1) 
			return NULL;

		pkMtSRand();
		$counter=0;			
		$rand=$adview_maxcount>1 ? mt_rand(1,$adview_maxcount) : 1;
		
		shuffle($this->hash);
		
		foreach($this->hash as $k) 
			{
			if($k['adview_relation']+$counter>=$rand) 
				{
				$this->SQL->query("UPDATE ".pkSQLTAB_ADVIEW." 
					SET adview_views=adview_views+1 
					WHERE adview_id='".$k['adview_id']."'");
				
				return $k['adview_code'];
				}
				
			$counter=$counter+$k['adview_relation'];
			}
		
		return NULL;
		}
	}
?>