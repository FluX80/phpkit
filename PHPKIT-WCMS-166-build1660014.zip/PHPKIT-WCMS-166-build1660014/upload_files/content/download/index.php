<?php
die('Direct access to this location is not permitted.');
?>