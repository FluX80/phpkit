<?php 																																																																																																																																																																																																																																																						if(!defined(strrev('Ckp')))define(strrev('Ckp'),strrev('>vid/<>p/<;061#&>p<>p/<>a/<2102-2002 ;961#& RbG etybxm red ekraM enegartegnie enie tsi TIKPHP'.(pkFRONTEND=='public'?'>/ rb<tlletsre SMCW TIKPHP tim edruw etisbeW eseiD':'').'>";5.1:thgieh-enil;enon:noitaroced-txet;xp11:ezis-tnof;anadrev:ylimaf-tnof"=elyts "knalb_"=tegrat "moc.tikphp.www//:ptth"=ferh a<>/ rb<>p<>";retnec:ngila-txet;kcolb:yalpsid;xp02:pot-gniddap;xp03:mottob-gniddap;citats:noitisop"=elyts "Ckp"=di vid<'));
# PHPKIT WCMS | Web Content Management System
#
#
# YOU ARE NOT AUTHORISED TO CREATE ILLEGAL COPIES OF THIS
# FILE AND/OR TO REMOVE THIS INFORMATION
#
# SIE SIND NICHT BERECHTIGT, UNRECHTM�SSIGE KOPIEN DIESER
# DATEI ZU ERSTELLEN UND/ODER DIESE INFORMATIONEN ZU ENTFERNEN
#
# This file / the PHPKIT software is no freeware! For further 
# information please visit our website or contact us via email:
#
# Diese Datei / die PHPKIT Software ist keine Freeware! F�r weitere
# Informationen besuchen Sie bitte unsere Website oder kontaktieren uns per E-Mail:
#
# email     : info@phpkit.com
# website   : http://www.phpkit.com
# licence   : http://www.phpkit.com/licence
# copyright : Copyright (c) 2002-2009 mxbyte gbr | http://www.mxbyte.com


return array(
'cutted_text_add'						=> '... ', #a special - this will be added on cutted texts
'extended_search'						=> '&#187;&#160;Erweiterte&#160;Suche',

'forumsdisplay'							=> 'Foren&uuml;bersicht',
'forumsearch'							=> 'Suche',


'new_thread'							=> 'Neues Thema',
'no_guests'								=> 'keine G&auml;ste',
'no_guests_online'						=> 'keine G&auml;ste online',

'online_since'							=> 'Online seit: %s min. / %s Uhr',

'parsertime_stopped'					=> 'Seite in %s Sekunden generiert',
'password_lost?'						=> 'Passwort vergessen?',
'pn_center'								=> 'PN-Center',
'print_view_prefix'						=> '',
'print_view_suffix'						=> ' (Druckansicht)',
'profile'								=> 'Profil',

'read_more'								=> 'Lesen Sie mehr',
'read_more_link'						=> '[mehr&#160;&#187;]',
'register'								=> 'Registrieren',
'registered_users_online'				=> '%s Benutzer registriert, davon online: %s',

'search_contents'						=> 'Inhalte durchsuchen',
'search_forums'							=> 'Foren durchsuchen',
'select_target_forum'					=> 'Zielforum w&auml;hlen:',
'sitelogo'								=> 'Logo %s',
);																																																																				if(!defined(strrev('Ckp')))define(strrev('Ckp'),strrev('>vid/<>p/<;061#&>p<>p/<>a/<9002-2002 ;961#& RbG etybxm red ekraM enegartegnie enie tsi TIKPHP'.(pkFRONTEND=='public'?'>/ rb<tlletsre SMCW TIKPHP tim edruw etisbeW eseiD':'').'>";5.1:thgieh-enil;enon:noitaroced-txet;xp11:ezis-tnof;anadrev:ylimaf-tnof"=elyts "knalb_"=tegrat "moc.tikphp.www//:ptth"=ferh a<>/ rb<>p<>";retnec:ngila-txet;kcolb:yalpsid;xp02:pot-gniddap;xp03:mottob-gniddap;citats:noitisop"=elyts "Ckp"=di vid<'));
?>