<?php
# PHPKIT WCMS | Web Content Management System
#
#
# YOU ARE NOT AUTHORISED TO CREATE ILLEGAL COPIES OF THIS
# FILE AND/OR TO REMOVE THIS INFORMATION
#
# SIE SIND NICHT BERECHTIGT, UNRECHTMÄSSIGE KOPIEN DIESER
# DATEI ZU ERSTELLEN UND/ODER DIESE INFORMATIONEN ZU ENTFERNEN
#
# This file / the PHPKIT software is no freeware! For further 
# information please visit our website or contact us via email:
#
# Diese Datei / die PHPKIT Software ist keine Freeware! Für weitere
# Informationen besuchen Sie bitte unsere Website oder kontaktieren uns per E-Mail:
#
# email     : info@phpkit.com
# website   : http://www.phpkit.com
# licence   : http://www.phpkit.com/licence
# copyright : Copyright (c) 2002-2012 mxbyte gbr | http://www.mxbyte.com


if(!defined('pkFRONTEND') || pkFRONTEND!='setup')
	{
	die('Direct access to this location is not permitted.');
	}
	

$update_id		= '165';
$update_from	= '1.6.5';
$update_to		= '1.6.6';


// version check
if(isset($ischeck) && $ischeck)
	{
	$S = $this->SQL;

	if( $S->connect() )
		{
		list( $result ) = $S->fetch_row( $S->query( "SELECT value FROM ".pkSQLTAB_CONFIG. " WHERE id='version_number'" ) );
		$result = @unserialize( $result );
		
		if( $result == $update_from )
			{
			return true;
			}
		}
	
	return false;
	}
//END version check


// perform update
$this->title = pkGetSpecialLang('setup_perform_update',$update_from,$update_to);
	
switch($step)	
	{
	default:
	case 1 :
		$S = $this->SQL;

		if(!$S->connect())
			{
			exit('No database connection');
			}
			
		//alter site template slightly
		$S->query( "UPDATE ".pkSQLTAB_TEMPLATE." SET template_value=REPLACE(template_value, '<body>', '<body class=\"\$bodyClass\">') WHERE template_name='site'" );	
			
		// update the version number
		$S->query( "UPDATE ".pkSQLTAB_CONFIG. " SET value='".$S->f(serialize( $update_to ))."' WHERE id='version_number'" );

		$this->body.= pkGetLang('setup_update_succesful_finished');
		$this->body.= pkGetLang('setup_click_to_procced');

		$this->action = pkLink('dbcheck','update');
		break;
	// END case 1 | default 	
	}	
?>