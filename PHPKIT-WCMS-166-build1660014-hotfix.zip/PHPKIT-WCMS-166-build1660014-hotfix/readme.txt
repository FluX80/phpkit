Hotfix f�r PHPKIT WCMS 1.6.6 (Buildnummer 1660014)
--------------------------------------------------

Der Hotfix ist f�r PHPKIT Version 1.6.6 (Build 1660013) und behebt einen
Fehler beim Datenbankexport in der Administration im Build 1660013.


Installation:
-------------

Kopieren Sie den Inhalt des Ordners "upload_files" deckungsgleich in das
Verzeichnis ihrer bestehenden PHPKIT Installation und �berschreiben Sie 
die Verzeichnisse "pk" und "pkinc" sowie die folgenden Dateien:
    pk/fx/default/css/base.css
    pkinc/admin/database.php
    pkinc/version.php


Detaillierte �nderung:
---------------------

pk/fx/default/css/base.css
    Korrektur der Hintergrundfarbe des Navigationsbereichs der Administration. 
    Das Laden einer Hintergrundgrafik wurde entfernt.

pkinc/admin/database.php
    Das Auslesen der Datenbanktabellen f�r den Datenbankexport wurde korrigiert
    und funktioniert nun wieder wie vorgesehen.

pkinc/version.php
    Aktualisierung der Buildnummer auf 1660014.


http://www.phpkit.com
mx|byte|gbr - 08.06.20012